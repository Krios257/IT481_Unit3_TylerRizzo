﻿using IT481_Unit2;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IT_481_U2_Assignment
{
    public partial class Form1 : Form
    {
        private Controller controller;
        private string user;
        private string password;
        private string server;
        private string database;

        public Form1()
        {
            InitializeComponent();
            textBox3.Text = "DESKTOP-795981Q";
            textBox4.Text = "Northwind";
            button1.Click += new EventHandler(Button1_Click);
            button2.Click += new EventHandler(Button2_Click);
            button3.Click += new EventHandler(Button3_Click);
            button4.Click += new EventHandler(Button4_Click);
            button5.Click += new EventHandler(Button5_Click);
            button6.Click += new EventHandler(Button6_Click);
            button7.Click += new EventHandler(Button7_Click);
        }

        private void Form1_Load(object sender, EventArgs e)
        {



        }


        private void Button1_Click(object sender, EventArgs e)
        {
            bool isValid = true;
            user = TextBox1.Text;
            password = textBox2.Text;
            server = textBox3.Text;
            database = textBox4.Text;


            if(user.Length == 0 || password.Length == 0 ||
                server.Length == 0 || database.Length ==0)
            {
                isValid = false;
                MessageBox.Show("You must enter user name, password, server, and database values");
            }

            if (isValid)
            {
                controller = new Controller("Server = DESKTOP-795981Q\\SQLEXPRESS02;" +
                                            "Trusted_Connection=true;" +
                                            "Database=Northwind;" +
                                            "User Instance=false;" +
                                            "Connection timeout=30");

                MessageBox.Show("Connection information sent");
            }

            

        }

        private void Button2_Click(object sender, EventArgs e)
        {

            string count = controller.GetCustomerCount();
            MessageBox.Show(count, "Customer count");

        }

        private void Button3_Click(object sender, EventArgs e)
        {
            string names = controller.GetCompanyNames();
            MessageBox.Show(names, "Company names");

        }

        private void Label9_Click(object sender, EventArgs e)
        {

        }

        private void Button4_Click(object sender, EventArgs e)
        {

            string count = controller.GetOrderCount();
            MessageBox.Show(count, "Order count");

        }

        private void Button5_Click(object sender, EventArgs e)
        {
            string names = controller.GetShipNames();
            MessageBox.Show(names, "Order Ship names");
        }

        private void Button6_Click(object sender, EventArgs e)
        {
            string count = controller.GetEmployeeCount();
            MessageBox.Show(count, "Employee count");
        }

        private void Button7_Click(object sender, EventArgs e)
        {
            string names = controller.GetEmployeeNames();
            MessageBox.Show(names, "Employee names");
        }
    }
}



