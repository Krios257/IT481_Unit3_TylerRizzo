﻿using System;
using System.Data.SqlClient;

namespace IT481_Unit2
{
    class DB
    {
        private string connectionString;
        SqlConnection cnn;
        public DB()
        {
            connectionString = "Server = DESKTOP-795981Q\\SQLEXPRESS; " +
                               "Trusted_Connection=true;" +
                               "Database=Northwind;" +
                               "User Instance=false;" +
                               "Connection timeout=30";
        }

        public DB(string conn)
        {
            connectionString = conn;
        }

        public string getCustomerCount()
        {
            Int32 count = 0;

            cnn = new SqlConnection(connectionString);
            cnn.Open();
            string countQuery = "select count(*) from customers;";
            SqlCommand cmd = new SqlCommand(countQuery, cnn);

            try
            {
                count = Convert.ToInt32(cmd.ExecuteScalar());
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);

            }
            return count.ToString();
        }


        public string getCompanyNames()
        {
            string names = "None";
            SqlDataReader dataReader;

            cnn = new SqlConnection(connectionString);
            cnn.Open();
            string countQuery = "select companyname from customers;";
            SqlCommand cmd = new SqlCommand(countQuery, cnn);
            dataReader = cmd.ExecuteReader();
            while (dataReader.Read())
            {
                try
                {
                    names = names + dataReader.GetValue(0) + "\n";
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }

            return names;
        }
    }
}

